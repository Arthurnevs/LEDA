package adt.bst.extended;

public class Teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FloorCeilBSTImpl f = new FloorCeilBSTImpl();
		Integer[] array = {10,5,15,12,30};
		System.out.println(f.floor(array, 28));
		
		
	}

}
